//
//  WriteToBLEManager.h
//  BLE_AiCare
//
//  Created by percy on 17/2/15.
//  Copyright © 2017年 com.percy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MasterSHAinfo.h"

@interface WriteToBLEManager : NSObject


+ (instancetype)shareManager;

// 0.用户信息写入（同步用户）
- (void)synchronousUserWithSex:(NSInteger)sex withHeight:(NSString *)height withAge:(NSString *)age;

// 1.同步用户信息 (更新用户)
- (void)upDataUserInformationModel:(MasterSHAinfo *)masterModel;

// 2.同步列表
- (void)synchronous_UserList:(MasterSHAinfo *)masterModel;

// 3.同步时间
- (void)synchronous_Equipment_Time;

// 4.获取历史数据
- (void)access_To_Historical_Data;

// 5.写入单位
- (void)write_To_Unit:(NSInteger)unitNumber;

@end
