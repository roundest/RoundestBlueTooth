//
//  BluetoothManager.m
//  BLE_AiCare
//
//  Created by percy on 15/11/10.
//  Copyright © 2015年 com.percy. All rights reserved.
//

#import "BluetoothManager.h"
#import "AnalysisBLEDataManager.h"   // 分析类

//servier uuid
static NSString *const AICARE_SERVICE_UUID = @"0000FFB0-0000-1000-8000-00805F9B34FB";
//characteristics uuid
static NSString *const AICARE_NOTIFY_CHARACTERISTIC_UUID = @"0000FFB2-0000-1000-8000-00805F9B34FB";
static NSString *const AICARE_WRITE_CHARACTERISTIC_UUID =  @"0000FFB1-0000-1000-8000-00805F9B34FB";

static NSString *AICARE_FFB3 =  @"0000FFB3-0000-1000-8000-00805F9B34FB";

@interface BluetoothManager () <CBCentralManagerDelegate,CBPeripheralDelegate>

@property (nonatomic, strong) CBCentralManager *pwCentralManager;
@property (nonatomic, strong) CBPeripheral *peripheral;

@property (nonatomic, strong) NSMutableArray *peripheralArray;
@property (nonatomic, weak) id<PeripheralAddDelegate> addDelegate;

@property (nonatomic, copy) NSString *connectPeripheralUUID;
@property (nonatomic, copy) NSString *connectPeripheralCharUUID;

@property (nonatomic, strong) CBCharacteristic *myCharacteristic;

@end


@implementation BluetoothManager

#pragma mark - Life cycle

+ (instancetype)shareManager
{
    static BluetoothManager *shareManager = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        shareManager = [[self alloc] init];
    });
    return shareManager;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self centralManager];
    }
    return self;
}

#pragma mark - Public methods

- (void)connectPeripheral:(CBPeripheral *)peripheral
{
    // 名字按照自家的称做修改
    if ([peripheral.name isEqualToString:@"SWAN"] || [peripheral.name isEqualToString:@"icomon"] || [peripheral.name isEqualToString:@"eufy T9140"] || [peripheral.name isEqualToString:@"himama"]) {
        self.connectPeripheralUUID = AICARE_SERVICE_UUID;
        self.connectPeripheralCharUUID = AICARE_NOTIFY_CHARACTERISTIC_UUID;
    }else{
        return;
    }
    
    // NSLog(@"111 %@, 22222 ",peripheral.identifier.UUIDString);

    self.peripheral = peripheral;
    [self.centralManager connectPeripheral:peripheral options:nil];
}


- (void)setPeripheralAddDelegate:(id<PeripheralAddDelegate>)delegate
{
    self.addDelegate = delegate;
}

#pragma mark - Private Methods
// 开启蓝牙扫描
- (void)startBleScan
{
    [self.centralManager scanForPeripheralsWithServices:@[[CBUUID UUIDWithString:AICARE_SERVICE_UUID]] options:@{CBCentralManagerScanOptionAllowDuplicatesKey : @ YES}];
}

// 关闭蓝牙扫描
- (void)closeBleAndDisconnect
{
    if (self.peripheral == nil) {
        return;
    }
    [self.centralManager stopScan];
    [self.centralManager cancelPeripheralConnection:self.peripheral];
}

- (void)stopScan_BLE{
    [self.centralManager stopScan];
}

// app向设备发送命令
- (void)sendDataToBle:(NSData *)data
{
    // NSLog(@"写入信息: %@",data);
    [self.peripheral writeValue:data forCharacteristic:self.myCharacteristic type:CBCharacteristicWriteWithoutResponse];
}


#pragma mark - CBCentralManagerDelegate
// 判断蓝牙状况
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    switch (central.state) {
        case CBCentralManagerStatePoweredOn:
            NSLog(@"CBCentralManagerStatePoweredOn==>蓝牙已打开");
            break;
        case CBCentralManagerStatePoweredOff:
            NSLog(@"CBCentralManagerStatePoweredOff==>蓝牙关闭状态");
            break;
        default:
            break;
    }
}

// 扫描到设备会进入方法
- (void)centralManager:(CBCentralManager *)central
 didDiscoverPeripheral:(CBPeripheral *)peripheral
     advertisementData:(NSDictionary<NSString *,id> *)advertisementData
                  RSSI:(NSNumber *)RSSI
{
    NSData *manufacturerData = [advertisementData valueForKeyPath:CBAdvertisementDataManufacturerDataKey];
    
    // 打印出扫描的信息;
    if (advertisementData.description.length > 0) {
        DLog(@"/-------advertisementData:%@--------",advertisementData.description);
        DLog(@"-------peripheral:%@--------/",peripheral.description);
    }
    
    // 标准是会收到: <ac02e215 afecb3a1> 是按照Byte值来数，是8位;
    if (manufacturerData.length < 8) {
        return;
    }
    
    // 抽取地址处理 <ac02e215 afecb3a1> 变成: A1:B3:EC:AF:15:E2
    NSString *bindString = @"";
    NSData *subData = [manufacturerData subdataWithRange:NSMakeRange(manufacturerData.length-8, 8)];
    bindString = subData.description;
    NSString *addressString = [self getVisiableIDUUID:bindString];
    NSLog(@" GG == %@ == GG",addressString);
    
    // 代理的方式传到界面上
    if ([self.addDelegate respondsToSelector:@selector(addPeripheralWithPeripheral:)]) {
        BLEModel *model = [[BLEModel alloc] init];
        model.backPeripheral = peripheral;
        model.backPeripheralString = addressString;
        [self.addDelegate addPeripheralWithPeripheral:model];
    }
}

// 连接到Peripherals-成功
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
//    NSLog(@"-- 成功连接外设 --：%@",peripheral.name);
    [self.centralManager stopScan];
    [self.peripheral setDelegate:self];
    [self.peripheral discoverServices:@[[CBUUID UUIDWithString:self.connectPeripheralUUID]]];
}

// 连接到Peripherals-失败
- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@">>>连接到名称为（%@）的设备-失败,原因:%@",[peripheral name],[error localizedDescription]);
}

//Peripherals断开连接
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@">>>外设连接断开连接 %@: %@\n", [peripheral name], [error localizedDescription]);
}

#pragma mark - CBPeripheralDelegate

// 扫描到Services
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
    if (error) {
        NSLog(@">>>Discovered services for %@ with error: %@", peripheral.name, [error localizedDescription]);
        return;
    }
    for (CBService *server in peripheral.services) {
        [self.peripheral discoverCharacteristics:nil forService:server];
    }
}

// 扫描到Characteristics
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    //在这里进行特征值的匹对，拿到特征值进行读写
    if ([service.UUID isEqual:[CBUUID UUIDWithString:self.connectPeripheralUUID]]) {
        for (CBCharacteristic *characteristic in service.characteristics) {
            if (characteristic.properties & CBCharacteristicPropertyNotify) {
                [peripheral readValueForCharacteristic:characteristic];
                [peripheral setNotifyValue:YES forCharacteristic:characteristic];
                NSLog(@"=---- %@ ----",characteristic);
            }

            if([characteristic.UUID isEqual:[CBUUID UUIDWithString:AICARE_WRITE_CHARACTERISTIC_UUID]]){
                self.myCharacteristic  = characteristic;
            }
        }
    }
}

// 获取的charateristic的值，数据解析
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    NSLog(@"didUpdateValueForCharacteristic: %@",characteristic.value);
    if (characteristic.value.length == 0){
        return;
    }
    
    // 回来的数据都丢去分析类里面进行处理
    [[AnalysisBLEDataManager shareManager] readBleComebackData:characteristic.value];

}

// 响应手机端发送数据给设备端 是否成功
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    if (error) {
        NSLog(@"Error writing characteristic value: %@",
              [error localizedDescription]);
        return;
    }
}

#pragma mark - 数据处理

/**
 *  蓝牙扫描到符合的地址处理
 *
 *  @param peripheralIDUUID 扫描回来的地址信息
 *
 *  @return 规范化地址返回
 */
- (NSString *)getVisiableIDUUID:(NSString *)peripheralIDUUID
{
    peripheralIDUUID = [peripheralIDUUID stringByReplacingOccurrencesOfString:@"-" withString:@""];
    peripheralIDUUID = [peripheralIDUUID stringByReplacingOccurrencesOfString:@"<" withString:@""];
    peripheralIDUUID = [peripheralIDUUID stringByReplacingOccurrencesOfString:@">" withString:@""];
    peripheralIDUUID = [peripheralIDUUID stringByReplacingOccurrencesOfString:@" " withString:@""];
    peripheralIDUUID = [peripheralIDUUID substringFromIndex:peripheralIDUUID.length - 12];
    peripheralIDUUID = [peripheralIDUUID uppercaseString];
    NSData *bytes = [peripheralIDUUID dataUsingEncoding:NSUTF8StringEncoding];
    Byte * myByte = (Byte *)[bytes bytes];
    
    NSMutableString *result = [[NSMutableString alloc] initWithString:@""];
    for (int i = 5; i >= 0; i--) {
        [result appendString:[NSString stringWithFormat:@"%@",[[NSString alloc] initWithBytes:&myByte[i*2] length:2 encoding:NSUTF8StringEncoding] ]];
    }
    
    for (int i = 1; i < 6; i++) {
        [result insertString:@":" atIndex:3*i-1 ];
    }
    
    return result;
}


#pragma mark - Setter and Getter

- (CBCentralManager *)centralManager
{
    if (!_pwCentralManager ) {
        _pwCentralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    }
    return _pwCentralManager;
}

- (NSMutableArray *)peripheralArray
{
    if (!_peripheralArray) {
        _peripheralArray = [[NSMutableArray alloc] init];
    }
    return _peripheralArray;
}

- (NSString *)connectPeripheralUUID
{
    if (_connectPeripheralUUID == nil) {
        _connectPeripheralUUID = [[NSString alloc] init];
    }
    return _connectPeripheralUUID;
}

- (NSString *)connectPeripheralCharUUID
{
    if (_connectPeripheralCharUUID == nil) {
        _connectPeripheralCharUUID  = [[NSString alloc] init];
    }
    return _connectPeripheralCharUUID;

}

- (CBCharacteristic *)myCharacteristic
{
    if (_myCharacteristic == nil) {
        _myCharacteristic = [CBCharacteristic new];
    }
    return _myCharacteristic;
}

@end
