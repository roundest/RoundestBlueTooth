//
//  AnalysisBLEDataManager.h
//  BLE_AiCare
//
//  Created by percy on 17/2/15.
//  Copyright © 2017年 com.percy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UserInfoModel.h"
#import "HistoryRecord.h"

@protocol UserInfoDelegate <NSObject>
@optional
- (void)responseUserInfo:(UserInfoModel *)infoModel;     // 返回最终测量的数据模型
- (void)handleStableVaule:(UserInfoModel *)infoModel;    // 返回稳定的数据模型
- (void)updataUserInfo;                                  // 测量完成调用--更新用户数据
- (void)historys_Information_Back:(NSMutableArray *)historyMutableArr;  // 历史记录打印
- (void)analysisBLEDataTip:(NSString *)tipString;        // 界面提示语句TipString (可删)
@end



@interface AnalysisBLEDataManager : NSObject

@property (nonatomic, weak) id<UserInfoDelegate>infoDelegate;

- (void)setUserInfoDelegate:(id<UserInfoDelegate>)delegate;

+ (instancetype)shareManager;

/**
 *  连接后称端回来的全部数据---分析处理接口
 *
 *  @param characteristicValue 设备数据(NSData)
 */
- (void)readBleComebackData:(NSData *)characteristicValue;

@end
