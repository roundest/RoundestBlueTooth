//
//  AnalysisBLEDataManager.m
//  BLE_AiCare
//
//  Created by percy on 17/2/15.
//  Copyright © 2017年 com.percy. All rights reserved.
//

#import "AnalysisBLEDataManager.h"
#import "HistoryRecord.h"
#import "WriteToBLEManager.h"
#import "MasterSHAinfo.h"

@interface AnalysisBLEDataManager ()

@property (nonatomic, strong) UserInfoModel *userInfoModel;        // 用户基本信息model
@property (nonatomic, strong) NSMutableData *historyDataS;         // 历史数据20+20个字节Data
@property (nonatomic, strong) NSMutableArray *historyMutableArr;   // 接受历史数据可变数组
@property (nonatomic, strong) NSString *tipString;                 // 提示语句

@end

@implementation AnalysisBLEDataManager
{
    float _weightsum;         //重量
    float _temperature;       //温度
    float _BMI;               //BMI
    float _fatRate;           //体脂率
    float _muscle;            //肌肉
    float _moisture;          //水分
    float _boneMass;          //骨量
    float _subcutaneousFat;   //皮下脂肪
    float _BMR;               //基础代谢率
    float _proteinRate;       //蛋白率
    int   _visceralFat;       //内脏脂肪
    float _physicalAge;       //生理年龄
    int _newAdc;              //阻抗值
}

- (void)setUserInfoDelegate:(id<UserInfoDelegate>)delegate {
    self.infoDelegate = delegate;
}

+ (instancetype)shareManager {
    static AnalysisBLEDataManager *shareManager = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        shareManager = [[self alloc] init];
    });
    return shareManager;
}

- (void)readBleComebackData:(NSData *)characteristicValue {
    
    Byte *testByte = (Byte *)[characteristicValue bytes];
    
    if (testByte[6] == 0XCE) {  // 0xCE时是 变化 体重(温度)数据
        _weightsum = testByte[2]*256 + testByte[3];
        _BMI=0;_fatRate=0;_subcutaneousFat=0;_visceralFat=0;_muscle=0;
        _BMR=0;_boneMass=0;_moisture=0;_physicalAge=0;_proteinRate=0;_temperature=0;
        if (testByte[1] == 0x03) { // AC03的称有温度数据
            _temperature = [self temperatureDataConversion:[NSString stringWithFormat:@"%@",characteristicValue]];
        }
        _tipString = [NSString stringWithFormat:@"不稳定体重:%.1f",_weightsum];
    }
    if (testByte[6] == 0XCA) {  // 0xCA时是 稳定 体重(温度)数据
        _weightsum = testByte[2]*256 + testByte[3];
        //NSLog(@"体重数据=== %f ===",_weightsum);
        if (testByte[1] == 0x03) { // AC03的称有温度数据
            _temperature = [self temperatureDataConversion:[NSString stringWithFormat:@"%@",characteristicValue]];
        }
        _userInfoModel.weightsum = _weightsum;
        _userInfoModel.temperature = _temperature;
        if ([self.infoDelegate respondsToSelector:@selector(handleStableVaule:)]) {
            [self.infoDelegate handleStableVaule:_userInfoModel];
        }
        _tipString = [NSString stringWithFormat:@"稳定体重:%.1f",_weightsum];
    }
    
    
    if (testByte[2] == 0XFE && testByte[6] == 0XCB)   // 连接上收到包裹才会跳入
    {
        if (testByte[3] == 0X00) {
            _weightsum = testByte[4]*256 + testByte[5];
        } else if (testByte[3] == 0X01) {
            _BMI = (float)(testByte[4]*256 +testByte[5])/10;
        } else if (testByte[3] == 0X02) {
            _fatRate = (float)(testByte[4]*256 +testByte[5])/10;
        } else if (testByte[3] == 0X03) {
            _subcutaneousFat = (float)(testByte[4]*256 +testByte[5])/10;
        } else if (testByte[3] == 0X04) {
            _visceralFat = testByte[4]*256 +testByte[5];
        } else if (testByte[3] == 0X05) {
            _muscle = (float)(testByte[4]*256 +testByte[5])/10;
        } else if (testByte[3] == 0X06) {
            _BMR = (testByte[4]*256 +testByte[5]);
        } else if (testByte[3] == 0X07) {
            _boneMass = (float)(testByte[4]*256 +testByte[5])/10;
        } else if (testByte[3] == 0X08) {
            _moisture = (float)(testByte[4]*256 +testByte[5])/10;
        } else if (testByte[3] == 0X09) {
            _physicalAge = testByte[4]*256 +testByte[5];
        } else if (testByte[3] == 0X0A) {
            _proteinRate = testByte[4]*256 +testByte[5];
        } else if (testByte[3] == 0xfc) {
            _tipString = @"体脂数据--结束发送";
        }else if (testByte[3] == 0XFF) {
            _tipString = @"脂肪数据测量--出错";
        }
    }else if (testByte[2] == 0xFD  && testByte[6] == 0xCB) {
        if (testByte[3] == 0x00) {
            _tipString = @"阻抗测量--中";
        }else if (testByte[3] == 0x01) {
            _newAdc = testByte[4]*256 + testByte[5];
            _tipString = @"阻抗测量--完成";
        }
        
    }else if (testByte[2] == 0xFE &&  testByte[6] == 0xcc) {
        
        if (testByte[3] == 0x07) {
            _tipString = @"设置MCU的时间--成功";
        }else if (testByte[3] == 0x08) {
            _tipString = @"设置MCU的时间--失败";
        }else if (testByte[3] == 0x09) {
            _tipString = @"设置MCU用户信息--成功";
        }else if (testByte[3] == 0x0a) {
            _tipString = @"设置MCU用户信息--失败";
        }else if (testByte[3] == 0x10 ) {
            // 更新用户个人信息回到称端 ====>>>要写在写入类里面
            if ([self.infoDelegate respondsToSelector:@selector(updataUserInfo)]) {
                [self.infoDelegate updataUserInfo];
            }
            _tipString = @"App主动更新用户称量后的数据";
        }
    }
    else if (testByte[2] == 0xfe &&  testByte[6] == 0xcf)
    {
        if (testByte[3] == 0x00) {
            _tipString = @"无历史数据";
        }else if (testByte[3] == 0x01) {
            // 开始发送历史数据
            _historyMutableArr = [[NSMutableArray alloc] init];
            _tipString = @"开始发送历史数据";
        }else if (testByte[3] == 0x02) {
            // 结束发送历史数据
            if ([self.infoDelegate respondsToSelector:@selector(historys_Information_Back:)]) {
                [self.infoDelegate historys_Information_Back:_historyMutableArr];
            }
            _tipString = @"结束发送历史数据";
        }
    }
    else if (testByte[2] == 0xff && testByte[3] == 0x00)
    {
        _historyDataS = [NSMutableData dataWithBytes:testByte length:20];
    }
    else if (testByte[0] == 0x01 && characteristicValue.length == 20)
    {
        NSData *twoData = [NSData dataWithBytes:testByte length:20];
        [_historyDataS appendData:twoData];
        //NSLog(@"添加后:%@",_historyDataS);
        if (_historyDataS.length == 40) {
            testByte = (Byte *)[_historyDataS bytes];
            HistoryRecord *historyRecord = [[HistoryRecord alloc] init];
            NSLog(@"%hhu---%hhu---%hhu",testByte[6],testByte[7],testByte[8]); 
            historyRecord.date = [NSString stringWithFormat:@"20%.2d-%.2d-%.2d",testByte[6],testByte[7],testByte[8]];
            historyRecord.time = [NSString stringWithFormat:@"%.2d:%.2d:%.2d",testByte[9],testByte[10],testByte[11]];
            
            //数值计算
            double weight = testByte[12]*256 + testByte[13]; weight /= 10;
            historyRecord.weightsum = [NSString stringWithFormat:@"%.1f",weight];
            historyRecord.BMI = [NSNumber numberWithFloat:(testByte[14]*256 +testByte[15])/10];
            historyRecord.fatRate = [NSNumber numberWithFloat:(testByte[16]*256 +testByte[17])/10];
            historyRecord.subcutaneousFat = [NSNumber numberWithFloat:(testByte[18]*256 +testByte[19])/10];
            historyRecord.visceralFat = [NSNumber numberWithFloat:(testByte[21]*256 +testByte[22])/10];
            historyRecord.muscle = [NSNumber numberWithFloat:(testByte[23]*256 +testByte[24])/10];
            historyRecord.BMR = [NSNumber numberWithFloat:(testByte[25]*256 +testByte[26])/10];
            historyRecord.boneMass = [NSNumber numberWithFloat:(testByte[27]*256 +testByte[28])/10];
            historyRecord.moisture = [NSNumber numberWithFloat:(testByte[29]*256 +testByte[30])/10];
            historyRecord.physicalAge = [NSNumber numberWithFloat:testByte[31]];
            historyRecord.proteinRate = [NSNumber numberWithFloat:(testByte[32]*256 +testByte[33])/10];
            
            
            historyRecord.userNum = [NSString stringWithFormat:@"%d",testByte[34]];
            if (testByte[35] == 0x01) {
                historyRecord.sex = @"1";  // 男
            }else{
                historyRecord.sex = @"2";  // 女
            }
            historyRecord.age = [NSString stringWithFormat:@"%d",testByte[36]];
            historyRecord.height = [NSString stringWithFormat:@"%d",testByte[37]];
            
            int adc = testByte[38]*256 + testByte[39];
            historyRecord.adc = [NSNumber numberWithInt:adc];
            NSLog(@"历史记录打印: %@ %@",historyRecord.date,historyRecord.time);
            [_historyMutableArr addObject:historyRecord];
        }
    }
    else if (testByte[2] == 0xfc && testByte[6] == 0xcf) {
        if (testByte[3] == 0x00) {
            _tipString = @"称端更新用户列表信息--成功";
        }else if (testByte[3] == 0x01) {
            _tipString = @"称端更新用户列表信息--失败";
        }else if (testByte[3] == 0x02) {
            _tipString = @"称端更新用户个人信息--成功";
        }else if (testByte[3] == 0x03) {
            _tipString = @"称端更新用户个人信息--失败";
        }
        
    }
    
    
    
    NSLog(@"-------%.1f------",_weightsum);
//    NSLog(@"=======%f======",_temperature);
//    NSLog(@"-------%f------",_BMI);
//    NSLog(@"=======%f======",_fatRate);
//    NSLog(@"=======%f======",_muscle);
//    NSLog(@"=======%f======",_moisture);
//    NSLog(@"=======%f======",_boneMass);
//    NSLog(@"=======%f======",_subcutaneousFat);
//    NSLog(@"=======%f======",_BMR);
//    NSLog(@"=======%f======",_proteinRate);
//    NSLog(@"=======%d======",_visceralFat);
//    NSLog(@"=======%f======",_physicalAge);
    
    _userInfoModel = [[UserInfoModel alloc] init];
    _userInfoModel.weightsum = _weightsum;
    _userInfoModel.temperature = _temperature;
    _userInfoModel.BMI = _BMI;
    _userInfoModel.fatRate = _fatRate;
    _userInfoModel.muscle = _muscle;
    _userInfoModel.moisture = _moisture;
    _userInfoModel.boneMass = _boneMass;
    _userInfoModel.subcutaneousFat = _subcutaneousFat;
    _userInfoModel.BMR = _BMR;
    _userInfoModel.proteinRate = _proteinRate;
    _userInfoModel.visceralFat = _visceralFat;
    _userInfoModel.physicalAge = _physicalAge;
    _userInfoModel.newAdc = _newAdc;
    
    if ([self.infoDelegate respondsToSelector:@selector(responseUserInfo:)]) {
        [self.infoDelegate responseUserInfo:_userInfoModel];
    }
    
    if ([self.infoDelegate respondsToSelector:@selector(analysisBLEDataTip:)]) {
        [self.infoDelegate analysisBLEDataTip:_tipString];
    }
}

/**
 *  AC03 人体温度称==温度处理
 *
 *  @param tempData 当前收到的ble数据
 *  @return
 */
- (float)temperatureDataConversion:(NSString *)tempData {
    //    NSString *stringData = @"<ac02fe06 f10ccc00>";
    NSString *stringDataF = [tempData substringWithRange:NSMakeRange(10, 1)];
    NSString *dataValue = [tempData substringWithRange:NSMakeRange(11, 1)];
    NSString *dataValue2 = [tempData substringWithRange:NSMakeRange(12, 2)];
    
    if ([stringDataF isEqualToString:@"f"]) {
        dataValue = [NSString stringWithFormat:@"0%@",dataValue];
        dataValue = [dataValue stringByAppendingString:dataValue2];
        unsigned long Value = strtoul([dataValue UTF8String], 0, 16);
        //NSLog(@" 得出准确的温度度数(绝对值) ========>>>>> %.1f", (float)Value);
        _temperature = -(float)Value;
    }else {
        dataValue = [NSString stringWithFormat:@"0%@",dataValue];
        dataValue = [dataValue stringByAppendingString:dataValue2];
        unsigned long Value = strtoul([dataValue UTF8String], 0, 16);
        //NSLog(@" 得出准确的温度度数(绝对值) ========>>>>> %.1f", (float)Value);
        _temperature = (float)Value;
    }
    NSString *TEMPstring = [NSString stringWithFormat:@"%.1f°C",(_temperature/10)];
    NSLog(@"dataValue==%@",TEMPstring);
    return _temperature/10;
}

#pragma mark - 懒加载
- (NSMutableArray *)historyMutableArr {
    if (_historyMutableArr == nil) {
        _historyMutableArr = [[NSMutableArray alloc] init];
    }
    return _historyMutableArr;
}

-  (UserInfoModel *)userInfoModel{
    if (_userInfoModel == nil) {
        _userInfoModel = [[UserInfoModel alloc] init];
    }
    return _userInfoModel;
}

@end
