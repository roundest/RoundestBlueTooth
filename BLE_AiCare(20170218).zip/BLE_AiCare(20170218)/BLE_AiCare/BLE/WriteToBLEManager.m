//
//  WriteToBLEManager.m
//  BLE_AiCare
//
//  Created by percy on 17/2/15.
//  Copyright © 2017年 com.percy. All rights reserved.
//

#define AC02or03 0x02  // 按自身的称端 0x02：体脂/人体秤、0x03：体脂/人体秤带温度显示

#import "WriteToBLEManager.h"
#import "BluetoothManager.h"
#import "MasterSHAinfo.h"
#import "NSDate+Utilities_y.h"

@interface WriteToBLEManager ()

@end


@implementation WriteToBLEManager

+ (instancetype)shareManager {
    static WriteToBLEManager *shareManager = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        shareManager = [[self alloc] init];
    });
    return shareManager;
}

#pragma mark - 公有
// 0.用户信息写入（同步用户）
- (void)synchronousUserWithSex:(NSInteger)sex withHeight:(NSString *)height withAge:(NSString *)age {
    
    /* 先告诉称端我现在是01用户 */
    Byte setUserNum[] = {0xac,AC02or03,0xfa,0x00,0x00,0x00,0xcc,0xce};
    setUserNum[3] = 0x01;    // ID号:设置为01
    setUserNum[7] = [self getBye8:setUserNum];
    NSData * setUserNumdata  = [[NSData alloc] initWithBytes:setUserNum length:8];
    [[BluetoothManager shareManager] sendDataToBle:setUserNumdata];
    
    /* 再把用户参数传送给称端 */
    Byte setUserCheck[] = {0xac,AC02or03,0xfb,0x00,0x00,0x00,0xcc,0x00};
    setUserCheck[3] = sex;
    setUserCheck[4] = age.integerValue;     // age
    setUserCheck[5] = height.integerValue;  //height
    setUserCheck[7] = [self getBye8:setUserCheck];
    NSData * setUserCheckData  = [[NSData alloc] initWithBytes:setUserCheck length:8];
    [[BluetoothManager shareManager] sendDataToBle:setUserCheckData];
}

// 1.同步用户信息 (更新用户)
- (void)upDataUserInformationModel:(MasterSHAinfo *)masterModel {
    /* App请求更新称端个人用户信息 */
    Byte firstUpCurrentByte[] = {0xac,AC02or03,0xfd,0x03,0x00,0x00,0xcf,0x00};
    firstUpCurrentByte[7] = [self getBye8:firstUpCurrentByte];
    NSData *firstUpCurrentData = [[NSData alloc] initWithBytes:firstUpCurrentByte length:8];
    [[BluetoothManager shareManager] sendDataToBle:firstUpCurrentData];
    
    // usr.usrID、性别、年龄、身高、体重(2byte)、阻抗(2byte)  【注:固定发20个字节】
    Byte upCurrentUsrInfoBytes[] = {0xac,AC02or03,0xFD,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
                                                                ,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
    upCurrentUsrInfoBytes[3] = 0x01;    // 标志位:用户个人信息更新
    upCurrentUsrInfoBytes[4] = 0x01;    // 用户ID1
    upCurrentUsrInfoBytes[5] = masterModel.userSex;
    upCurrentUsrInfoBytes[6] = [masterModel.userAge intValue];     // 年龄
    upCurrentUsrInfoBytes[7] = [masterModel.userHeight intValue];  // 身高
    
    NSInteger weightInt = masterModel.userWeigth.floatValue*10;
    upCurrentUsrInfoBytes[8] =  (Byte)((weightInt >>8) & 0xff);  // 体重高字节;
    upCurrentUsrInfoBytes[9] = (Byte)(weightInt & 0xff);         // 体重低字节;
    
    NSInteger adcInt = masterModel.userAdc.integerValue;
    upCurrentUsrInfoBytes[10] = (Byte)((adcInt>>8) & 0xff);           // 阻抗高字节
    upCurrentUsrInfoBytes[11] = (Byte)(adcInt & 0xff);                // 阻抗低字节
    NSData *upCurrentUsrInfoData = [[NSData alloc] initWithBytes:upCurrentUsrInfoBytes length:20];
    [[BluetoothManager shareManager] sendDataToBle:upCurrentUsrInfoData]; // 蓝牙返回<AC02or03fc02 0000cfcd>为正确
    NSLog(@"写入当前用户信息==%@",upCurrentUsrInfoData);
}

// 2.同步列表
- (void)synchronous_UserList:(MasterSHAinfo *)masterModel{
    
    // 数据列表开始发送
    Byte usrBytes[] = {0xac,AC02or03,0xfd,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
                                    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
    usrBytes[3] = 0x00;        // 用户列表信息
    usrBytes[4] = 0x01;        // ID号(可以0x01~0x08)
    usrBytes[5] = masterModel.userSex;
    usrBytes[6] = masterModel.userAge.integerValue;
    usrBytes[7] = masterModel.userHeight.integerValue;
    
    NSInteger weightInt = masterModel.userWeigth.floatValue*10;// 传值下去要*10（如：62.8公斤 ==>628）
    usrBytes[8] = (weightInt & 0x0f00)/16/16;     // 体重高位
    usrBytes[9] = (weightInt & 0x0ff);            // 体重低位
    
    NSInteger adcInt = masterModel.userAdc.integerValue;
    usrBytes[10] = (adcInt & 0x0f00)/16/16;        // 阻抗高位
    usrBytes[11] = (adcInt & 0x0ff);               // 阻抗低位
    NSData * usrData = [[NSData alloc] initWithBytes:usrBytes length:20];
    [[BluetoothManager shareManager] sendDataToBle:usrData];
    
    // 数据列表已经发送完全
    Byte finishBytes[] = {0xAC,AC02or03,0xfd,0x02,0x00,0x00,0xcf,0xce};
    NSData * finishData = [[NSData alloc] initWithBytes:finishBytes length:8];
    [[BluetoothManager shareManager] sendDataToBle:finishData];
}

// 3.同步时间
- (void)synchronous_Equipment_Time {
    Byte dateByte[] = {0xac,AC02or03,0xfd,0x00,0x00,0x00,0xcc,0x00};
    NSDate *date = [NSDate date];
    dateByte[3] = date.year - 2000;
    dateByte[4] = date.month;
    dateByte[5] = date.day;
    dateByte[7] = [self getBye8:dateByte];
    NSData *dateData = [[NSData alloc] initWithBytes:dateByte length:8];
    [[BluetoothManager shareManager] sendDataToBle:dateData];
    
    dateByte[2] = 0xFC;
    dateByte[3] = date.hour;
    dateByte[4] = date.minute;
    dateByte[5] = date.seconds;
    dateByte[7] = [self getBye8:dateByte];
    NSData *timeData = [[NSData alloc] initWithBytes:dateByte length:8];
    [[BluetoothManager shareManager] sendDataToBle:timeData];
    NSLog(@"==--%@",timeData);
}

// 4.获取历史数据
- (void)access_To_Historical_Data {
    Byte dateByte[] = {0xac,AC02or03,0xff,0x00,0x00,0x00,0xcf,0x00};
    dateByte[7] = [self getBye8:dateByte];
    NSData *historicalSync = [[NSData alloc] initWithBytes:dateByte length:8];
    [[BluetoothManager shareManager] sendDataToBle:historicalSync];
}

// 5.写入单位
- (void)write_To_Unit:(NSInteger)unitNumber {
    Byte unitBytes[] = {0xac,0x02,0xfe,0x06,0x00,0x00,0xcc,0x00};
    unitBytes[4] = unitNumber;
    unitBytes[7] = [self getBye8:unitBytes];
    NSData *unitData = [[NSData alloc] initWithBytes:unitBytes length:8];
    [[BluetoothManager shareManager] sendDataToBle:unitData];
}

#pragma mark - 私有

// 校验和(BYTE8 = BYTE3 + BYTE4 + BYTE5 + BYTE6 + BYTE7,结果取低8位)
- (Byte )getBye8:(Byte[])data
{
    Byte byte8 = data[2] + data[3] + data[4] + data[5] +data[6];
    byte8 = (unsigned char) ( byte8 & 0x00ff);
    return byte8;
}

@end
