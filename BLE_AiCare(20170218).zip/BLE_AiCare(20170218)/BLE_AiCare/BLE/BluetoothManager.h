//
//  BluetoothManager.h
//  BLE_AiCare
//
//  Created by percy on 15/11/10.
//  Copyright © 2015年 com.percy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>   // 添加蓝牙库文件
#import "BLEModel.h"                      // 蓝牙外设信息model

// 地址传输代理
@protocol PeripheralAddDelegate <NSObject>
@optional
- (void)addPeripheralWithPeripheral:(BLEModel *)peripheralModel;
@end

@interface BluetoothManager : NSObject

+ (instancetype)shareManager;

- (void)startBleScan;                // 开启蓝牙扫描
- (void)stopScan_BLE;                // 停止蓝牙扫描
- (void)closeBleAndDisconnect;       // 断开连接

- (void)setPeripheralAddDelegate:(id<PeripheralAddDelegate>)delegate;

- (void)connectPeripheral:(CBPeripheral *)peripheral;

- (void)sendDataToBle:(NSData *)data;

@end
