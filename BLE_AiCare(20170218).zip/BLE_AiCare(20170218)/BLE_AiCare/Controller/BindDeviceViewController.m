//
//  BindDeviceViewController.m
//  BLE_AiCare
//
//  Created by percy on 15/11/9.
//  Copyright © 2015年 com.percy. All rights reserved.
//  

#import "BindDeviceViewController.h"
#import "BluetoothManager.h"
#import "ViewController.h"

@interface BindDeviceViewController () <UITableViewDelegate,UITableViewDataSource,PeripheralAddDelegate>

@property (nonatomic, strong)UITableView *BleTableView;
@property (nonatomic, strong) NSMutableArray *peripheralArray;   
@property (nonatomic, assign) BOOL isAddPeripheraling;           //判断是否正在增加


@end

@implementation BindDeviceViewController

#pragma mark - ================= 视图 ==========================
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:235/255.0 green:250/255.0 blue:250/255.0 alpha:1.0];
    
    _BleTableView = [[UITableView alloc]init];
    _BleTableView.frame = CGRectMake(25, 230, self.view.frame.size.width - 50, 300);
    _BleTableView.dataSource = self;
    _BleTableView.delegate = self;
    [self.view addSubview:_BleTableView];
    
    [self BackButton];        //返回按钮
    [self ConnectionBtn];     //开始扫描按钮
    [self DisconnectionBtn];  //断开扫描按钮
    
    [[BluetoothManager shareManager] startBleScan];
    [[BluetoothManager shareManager] setPeripheralAddDelegate:self];
    
}

//返回主页面按钮
-(void)BackButton
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(25, 50, 150, 50);
    [btn setTitle:@"<<<点击返回" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    btn.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(blackMyView) forControlEvents:UIControlEventTouchUpInside];
}
-(void)blackMyView
{
    [self dismissViewControllerAnimated:YES completion:^{
        [[BluetoothManager shareManager] stopScan_BLE];
    }];
}

// 开始扫描按钮
- (void)ConnectionBtn
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(25, 110, 150, 50);
    [btn setTitle:@"开始扫描" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    btn.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(scanPeripheral) forControlEvents:UIControlEventTouchUpInside];
}

// 断开连接按钮
- (void)DisconnectionBtn
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(25, 170, 150, 50);
    [btn setTitle:@"断开连接" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    btn.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(stopScan) forControlEvents:UIControlEventTouchUpInside];
}

- (void)scanPeripheral
{
    [[BluetoothManager shareManager] startBleScan];
    NSLog(@"开始扫描");
}

- (void)stopScan
{
    [[BluetoothManager shareManager] closeBleAndDisconnect];
    NSLog(@"断开扫描 && 断开连接");
}


#pragma mark - PeripheralAddDelegate

- (void)addPeripheralWithPeripheral:(BLEModel  *)peripheralModel
{
    //5.处理相同的地址信息
    if (self.isAddPeripheraling == YES)
        return;
    self.isAddPeripheraling = YES;
    if (self.peripheralArray.count == 0) {
        [self.peripheralArray addObject:peripheralModel];
        [self.BleTableView reloadData];
    }
    BOOL willAdd = YES;
    for (BLEModel *model in self.peripheralArray)
    {
        if ([model.backPeripheral.description isEqualToString:peripheralModel.backPeripheral.description])
        {
            willAdd = NO;
        }
    }
    if (willAdd) {
        [self.peripheralArray addObject:peripheralModel];
        [self.BleTableView reloadData];
    }
    self.isAddPeripheraling = NO;
    
}


#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.peripheralArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"];
    }
    
    BLEModel *peripheralModel = self.peripheralArray[indexPath.row];
    cell.textLabel.text = peripheralModel.backPeripheral.name;
    cell.detailTextLabel.text = peripheralModel.backPeripheralString;

    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    BLEModel *peripheralModel = self.peripheralArray[indexPath.row];
    [[BluetoothManager shareManager] connectPeripheral:peripheralModel.backPeripheral];
    if ([self.macDelegate respondsToSelector:@selector(backMacAddress:)]) {
        [self.macDelegate backMacAddress:peripheralModel.backPeripheralString];
        [self blackMyView];
    }
}


#pragma mark - Setter and Getter

- (NSMutableArray *)peripheralArray
{
    if (_peripheralArray == nil) {
        _peripheralArray = [[NSMutableArray alloc] init];
    }
    return _peripheralArray;
}


@end
