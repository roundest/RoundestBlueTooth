//
//  BindDeviceViewController.h
//  BLE_AiCare
//
//  Created by percy on 15/11/9.
//  Copyright © 2015年 com.percy. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BackMacAddressDelegate <NSObject>
- (void)backMacAddress:(NSString *)macAddress;   // 返回蓝牙地址
@end



@interface BindDeviceViewController : UIViewController

@property (nonatomic) id<BackMacAddressDelegate> macDelegate;

@end
