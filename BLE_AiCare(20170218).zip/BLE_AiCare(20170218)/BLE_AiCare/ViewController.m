//
//  ViewController.m
//  BLE_AiCare
//
//  Created by percy on 15/11/4.
//  Copyright © 2015年 com.percy. All rights reserved.
//

#import "ViewController.h"

#import "BindDeviceViewController.h"   //连接页面View
#import "BluetoothManager.h"

#import "AnalysisBLEDataManager.h"
#import "WriteToBLEManager.h"
#import "HistoryView.h"

@interface ViewController () <UserInfoDelegate, BackMacAddressDelegate>

@property (weak, nonatomic) IBOutlet UIButton *connectedDevicesButton;

@property (weak, nonatomic) IBOutlet UISegmentedControl *sexSegmentedC;
@property (weak, nonatomic) IBOutlet UITextField *ageTextF;
@property (weak, nonatomic) IBOutlet UITextField *heightTextF;
@property (weak, nonatomic) IBOutlet UITextField *weightTextF;
@property (weak, nonatomic) IBOutlet UITextField *adcTextF;
@property (weak, nonatomic) IBOutlet UISegmentedControl *unitSegmentedControl;

@property (nonatomic, strong) MasterSHAinfo *masterSHAinfo_model;

- (IBAction)SyncUserInformation:(id)sender;                             //同步用户信息
- (IBAction)updataUserInfomation:(id)sender;                            //更新用户信息
- (IBAction)SyncList:(id)sender;                                        //同步列表
- (IBAction)SyncTime:(id)sender;                                        //同步时间
- (IBAction)AccessHistoricalData:(id)sender;                            //获取历史数据

- (IBAction)ChooseUnit:(UISegmentedControl *)Segmented;                 //选择单位

////////////////////////////////////////////////////////////////////////////////////////////
/**
 * 实时数据显示UILabel
 */
@property (weak, nonatomic) IBOutlet UILabel *weightsumValue;
@property (weak, nonatomic) IBOutlet UILabel *BMIValue;
@property (weak, nonatomic) IBOutlet UILabel *fatRateValue;
@property (weak, nonatomic) IBOutlet UILabel *muscleValue;
@property (weak, nonatomic) IBOutlet UILabel *moistureValue;
@property (weak, nonatomic) IBOutlet UILabel *boneMassValue;
@property (weak, nonatomic) IBOutlet UILabel *BMRValue;
@property (weak, nonatomic) IBOutlet UILabel *visceralFatValue;
@property (weak, nonatomic) IBOutlet UILabel *subcutaneousFatValue;
@property (weak, nonatomic) IBOutlet UILabel *proteinRateValue;
@property (weak, nonatomic) IBOutlet UILabel *physicalAgeValue;
@property (weak, nonatomic) IBOutlet UILabel *AdcValue;
@property (weak, nonatomic) IBOutlet UILabel *tempValue;
@property (weak, nonatomic) IBOutlet UILabel *tipString;

////////////////////////////////////////////////////////////////////////////////////////////
@property (nonatomic, assign) float weightFloat;               // 蓝牙回来的重量
@property (nonatomic, strong) HistoryView *historyView;        // 历史View
@property (nonatomic, copy) NSString *historyString;           // 历史字符串


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 遵循协议
    [[AnalysisBLEDataManager shareManager] setUserInfoDelegate:self];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(uiTouch)];
    [self.view addGestureRecognizer:tap];
}

#pragma mark - UserInfoDelegate

- (void)handleStableVaule:(UserInfoModel *)infoModel {
    _weightTextF.text = [NSString stringWithFormat:@"%.1f",infoModel.weightsum/10];
    _tempValue.text   = [NSString stringWithFormat:@"%.1f°C",infoModel.temperature];
}

- (void)responseUserInfo:(UserInfoModel *)infoModel {
    
    _weightFloat = infoModel.weightsum/10;

    self.weightsumValue.text            = [self getgetUnitedWeight:infoModel.weightsum/10 unit:_unitSegmentedControl.selectedSegmentIndex];
    self.BMIValue.text                  = [NSString stringWithFormat:@"%.1f",infoModel.BMI];
    self.fatRateValue.text              = [NSString stringWithFormat:@"%.1f",infoModel.fatRate];
    self.muscleValue.text               = [NSString stringWithFormat:@"%.1f％",infoModel.muscle];
    self.moistureValue.text             = [NSString stringWithFormat:@"%.1f％",infoModel.moisture];
    self.boneMassValue.text             = [NSString stringWithFormat:@"%.1f",infoModel.boneMass];
    self.subcutaneousFatValue.text      = [NSString stringWithFormat:@"%.1f％",infoModel.subcutaneousFat];
    self.BMRValue.text                  = [NSString stringWithFormat:@"%.1fkcal",infoModel.BMR];
    self.proteinRateValue.text          = [NSString stringWithFormat:@"%.1f％",infoModel.proteinRate/10];
    self.visceralFatValue.text          = [NSString stringWithFormat:@"%d",infoModel.visceralFat];
    self.physicalAgeValue.text          = [NSString stringWithFormat:@"%.1f",infoModel.physicalAge];
    self.AdcValue.text                  = [NSString stringWithFormat:@"%d",infoModel.newAdc];
    self.tempValue.text                 = [NSString stringWithFormat:@"%.1f°C",infoModel.temperature];

    _weightTextF.text = [NSString stringWithFormat:@"%.1f",infoModel.weightsum/10];
    _adcTextF.text    = [NSString stringWithFormat:@"%d",infoModel.newAdc];
}

- (void)updataUserInfo {
    // 更新用户个人信息回到称端 ====>>>要写在写入类里面
    [self updataUserInfomation_Data];
}

- (void)historys_Information_Back:(NSMutableArray *)historyMutableArr {
    // 历史数据打印
    NSMutableString *Mstring = [[NSMutableString alloc] init];
    for (HistoryRecord *historyRecord in historyMutableArr) {
        NSString *string1 = [NSString stringWithFormat:@"时间:%@ %@",historyRecord.date,historyRecord.time];
        NSString *string2 = [NSString stringWithFormat:@"个人信息:ID%@ 性别%@ 年龄%@ 身高%@ 体重%@ 阻抗%@",historyRecord.userNum,historyRecord.sex,historyRecord.age,historyRecord.height,historyRecord.weightsum,historyRecord.adc];
        NSString *string3 = [NSString stringWithFormat:@"[BMI=%@, BFR(体脂率)=%@,SFR(皮下脂肪率)=%@, UVI(内脏脂肪指数)=%@, ROM(肌肉率)=%@, BMR(基础代谢率)=%@, BM(骨量)=%@, MOI(水含量)=%@, PA(身体年龄)=%@, PP(蛋白率)=%@]",historyRecord.BMI,historyRecord.fatRate,historyRecord.subcutaneousFat,historyRecord.visceralFat,historyRecord.muscle,historyRecord.BMR,historyRecord.boneMass,historyRecord.moisture,historyRecord.physicalAge,historyRecord.proteinRate];
        _historyString = [NSString stringWithFormat:@"%@\n%@\n%@\n\n",string1,string2,string3];
        [Mstring appendString:_historyString];
    }
    _historyView.TextF.text = Mstring;
}

- (void)analysisBLEDataTip:(NSString *)tipString {
    _tipString.text = tipString;
}

#pragma mark - BackMacAddressDelegate
- (void)backMacAddress:(NSString *)macAddress {
    [_connectedDevicesButton setTitle:macAddress forState:UIControlStateNormal];
}

#pragma mark - 点击事件

- (IBAction)Click_Ble:(id)sender {
    NSLog(@"跳转到设置界面");
    BindDeviceViewController *bindDeviceView = [[BindDeviceViewController alloc]init];
    bindDeviceView.macDelegate = self;
    [self presentViewController:bindDeviceView animated:YES completion:nil];
}

- (IBAction)SyncUserInformation:(id)sender {
    NSLog(@"同步用户");
    // 同步用户只需要知道 ID号(如：01)， 性别、身高、年龄
    NSInteger sexInteger = _sexSegmentedC.selectedSegmentIndex==0 ? 1:2;;
    [[WriteToBLEManager shareManager] synchronousUserWithSex:sexInteger withHeight:_heightTextF.text withAge:_ageTextF.text];
}

- (IBAction)updataUserInfomation:(id)sender {
    NSLog(@"更新用户");
    [self updataUserInfomation_Data];
}

- (IBAction)SyncList:(id)sender {
    NSLog(@"同步列表");
    _masterSHAinfo_model = [[MasterSHAinfo alloc] init];
    _masterSHAinfo_model.userSex = _sexSegmentedC.selectedSegmentIndex==0 ? 1:2;
    _masterSHAinfo_model.userAge = _ageTextF.text;
    _masterSHAinfo_model.userHeight = _heightTextF.text;
    _masterSHAinfo_model.userWeigth = [NSString stringWithFormat:@"%f",_weightFloat];
    _masterSHAinfo_model.userAdc = _AdcValue.text;
    
    [[WriteToBLEManager shareManager] synchronous_UserList:_masterSHAinfo_model];
}

- (IBAction)SyncTime:(id)sender {
    NSLog(@"同步时间");
    // 时间同步
    [[WriteToBLEManager shareManager] synchronous_Equipment_Time];
}

- (IBAction)AccessHistoricalData:(id)sender {
    // 请求历史记录
    [[WriteToBLEManager shareManager] access_To_Historical_Data];
    
    NSArray *nib = [[NSBundle mainBundle]loadNibNamed:@"HistoryView" owner:self options:nil];
    _historyView = [nib objectAtIndex:0];
    _historyView.frame = CGRectMake(5, 25, self.view.bounds.size.width - 10, self.view.bounds.size.height-50);
    [_historyView.cancelButton addTarget:self action:@selector(colseButton) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_historyView];
}

#pragma mark - 单位换算
// 转换单位selectedSegmentIndex
- (IBAction)ChooseUnit:(UISegmentedControl *)Segmented {
    [[WriteToBLEManager shareManager] write_To_Unit:Segmented.selectedSegmentIndex];
    _weightsumValue.text = [self getgetUnitedWeight:_weightFloat unit:Segmented.selectedSegmentIndex];
}

// 标准换算单位的方法(重要)
- (NSString *)getgetUnitedWeight:(float)weight unit:(NSInteger)unit
{
    NSString *unitWeight;
    if (unit == 0) {
        unitWeight = [NSString stringWithFormat:@"%.1fkg",weight];
    } else if (unit == 1) {
        unitWeight = [NSString stringWithFormat:@"%.1flb",weight*2.2046226f];
    } else if (unit == 2) {
        unitWeight = [self kg2St:weight];
    } else if (unit == 3) {
        unitWeight = [NSString stringWithFormat:@"%.1f斤",weight*2];
    }else {
        unitWeight = [NSString stringWithFormat:@"%.1f",weight];
    }
    return unitWeight;
}

- (NSString *)kg2St:(float)kgWeight {
    NSString *oneString = [NSString stringWithFormat:@"%d",(int)(kgWeight*2.2046226f)/14];
    NSString *twoString = [NSString stringWithFormat:@"%d",((int)(kgWeight*2.2046226f)%14)];
    return [NSString stringWithFormat:@"%@:%@st",oneString,twoString];
}

#pragma mark -
// 用户数据打包成model，同步用户信息
- (void)updataUserInfomation_Data {
    _masterSHAinfo_model = [[MasterSHAinfo alloc] init];
    _masterSHAinfo_model.userSex = _sexSegmentedC.selectedSegmentIndex==0 ? 1:2;
    _masterSHAinfo_model.userAge = _ageTextF.text;
    _masterSHAinfo_model.userHeight = _heightTextF.text;
    _masterSHAinfo_model.userWeigth = _weightTextF.text;
    _masterSHAinfo_model.userAdc = _adcTextF.text;
    
    // 同步用户信息
    [[WriteToBLEManager shareManager] upDataUserInformationModel:_masterSHAinfo_model];
}

- (void)colseButton {
    [_historyView removeFromSuperview];
}

- (void)uiTouch {
    [self.view endEditing:YES];
}

@end





