//
//  HistoryView.h
//  BLE_AiCare
//
//  Created by percy on 17/2/17.
//  Copyright © 2017年 com.percy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryView : UIView
@property (weak, nonatomic) IBOutlet UITextView *TextF;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;

@end
