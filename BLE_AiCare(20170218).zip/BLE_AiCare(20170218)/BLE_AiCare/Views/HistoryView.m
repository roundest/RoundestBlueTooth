//
//  HistoryView.m
//  BLE_AiCare
//
//  Created by percy on 17/2/17.
//  Copyright © 2017年 com.percy. All rights reserved.
//

#import "HistoryView.h"

@implementation HistoryView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
