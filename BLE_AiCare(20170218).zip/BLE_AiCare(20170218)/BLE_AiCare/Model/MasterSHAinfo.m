//
//  MasterSHAinfo.m
//  BLE_AiCare
//
//  Created by percy on 15/11/13.
//  Copyright © 2015年 com.percy. All rights reserved.
//

#import "MasterSHAinfo.h"

@implementation MasterSHAinfo

@end
