//
//  MasterSHAinfo.h
//  BLE_AiCare
//
//  Created by percy on 15/11/13.
//  Copyright © 2015年 com.percy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MasterSHAinfo : NSObject

@property (nonatomic, assign) NSInteger userSex;

@property (nonatomic, copy) NSString *userAge;

@property (nonatomic, copy) NSString *userHeight;

@property (nonatomic, copy) NSString *userWeigth;

@property (nonatomic, copy) NSString *userAdc;

@end
