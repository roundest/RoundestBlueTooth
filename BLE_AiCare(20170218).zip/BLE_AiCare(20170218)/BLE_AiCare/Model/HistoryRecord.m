//
//  HistoryRecord.m
//  BLE_AiCare
//
//  Created by percy on 15/11/16.
//  Copyright © 2015年 com.percy. All rights reserved.
//

#import "HistoryRecord.h"

@implementation HistoryRecord

@end
