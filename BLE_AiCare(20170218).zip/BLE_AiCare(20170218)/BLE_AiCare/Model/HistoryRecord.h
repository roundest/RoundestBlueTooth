//
//  HistoryRecord.h
//  BLE_AiCare
//
//  Created by percy on 15/11/16.
//  Copyright © 2015年 com.percy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HistoryRecord : NSObject

@property (nonatomic, copy) NSString *date;        //日期.2015-11-01
@property (nonatomic, copy) NSString *time;        //时间.01:19:01

//参数
@property (nonatomic, copy) NSString *weightsum;           //重量

@property (nonatomic, strong) NSNumber *BMI;               //BMI

@property (nonatomic, strong) NSNumber *fatRate;           //体脂率

@property (nonatomic, strong) NSNumber *muscle;            //肌肉

@property (nonatomic, strong) NSNumber *moisture;          //水分

@property (nonatomic, strong) NSNumber *boneMass;          //骨量

@property (nonatomic, strong) NSNumber *subcutaneousFat;   //皮下脂肪

@property (nonatomic, strong) NSNumber *BMR;               //基础代谢率

@property (nonatomic, strong) NSNumber *proteinRate;       //蛋白率

@property (nonatomic, strong) NSNumber *visceralFat;       //内脏脂肪

@property (nonatomic, strong) NSNumber *physicalAge;       //生理年龄



@property (nonatomic, copy) NSString *userNum;
@property (nonatomic, copy) NSString *sex;
@property (nonatomic, copy) NSString *age;
@property (nonatomic, copy) NSString *height;

@property (nonatomic, strong) NSNumber *adc;              //阻抗值



@end
