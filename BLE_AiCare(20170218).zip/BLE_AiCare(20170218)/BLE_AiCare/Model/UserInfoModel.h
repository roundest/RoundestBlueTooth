//
//  UserInfoModel.h
//  BLE_AiCare
//
//  Created by percy on 15/11/10.
//  Copyright © 2015年 com.percy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserInfoModel : NSObject


@property (nonatomic, assign) float weightsum;           //重量

@property (nonatomic, assign) float temperature; // 温度

@property (nonatomic, assign) float BMI;               //BMI

@property (nonatomic, assign) float fatRate;           //体脂率

@property (nonatomic, assign) float muscle;            //肌肉

@property (nonatomic, assign) float moisture;          //水分

@property (nonatomic, assign) float boneMass;          //骨量

@property (nonatomic, assign) float subcutaneousFat;   //皮下脂肪

@property (nonatomic, assign) float BMR;               //基础代谢率

@property (nonatomic, assign) float proteinRate;       //蛋白率

@property (nonatomic, assign) int visceralFat;       //内脏脂肪

@property (nonatomic, assign) float physicalAge;       //生理年龄

@property (nonatomic, assign) int newAdc;              //阻抗值



@end
