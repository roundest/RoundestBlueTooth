//
//  BLEModel.m
//  BLE_AiCare
//
//  Created by percy on 15/11/15.
//  Copyright © 2015年 com.percy. All rights reserved.
//

#import "BLEModel.h"

@implementation BLEModel

@end
